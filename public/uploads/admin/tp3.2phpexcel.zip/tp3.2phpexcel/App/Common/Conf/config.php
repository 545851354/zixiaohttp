<?php
return array(
	//'配置项'=>'配置值'
      'SHOW_PAGE_TRACE'=>true,
      'URL_HTML_SUFFIX'=>'.html',
      'DB_TYPE' => 'mysql',
	  'DB_HOST' => 'localhost',
	  'DB_NAME' => 'test',
	  'DB_USER' => 'root',//用户
	  'DB_PWD' => '123456t',//密码
	  'DB_PORT' => '3306',
	  'DB_PREFIX' => 'sz_',

);