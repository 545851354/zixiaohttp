<?php
define('APP_DEBUG',True);
define("APP_PATH","./App/");
include('./ThinkPHP/ThinkPHP.php');
?>