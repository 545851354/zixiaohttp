<?php

  /**
  * ProjectTaskLists 
  *
  * @http://www.projectpier.org/
  */
  class ProjectTaskLists extends BaseProjectTaskLists {
  
  } // ProjectTaskLists 

?>