<?php

  /**
  * Plugin class
  *
  * @http://www.projectpier.org/
  */
  class Plugin extends BasePlugin {
    
  } // Plugin 

?>