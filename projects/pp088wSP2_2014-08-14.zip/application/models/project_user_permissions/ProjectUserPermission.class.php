<?php

  /**
  * ProjectUserPermission class
  *
  * @author Brett Edgar (TheWalrus) True Digital Security, Inc. www.truedigitalsecurity.com
  * @http://www.projectpier.org/
  */
  class ProjectUserPermission extends BaseProjectUserPermission {
      
  } // ProjectUserPermission

?>