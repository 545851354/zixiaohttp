<?php

  /**
  * Permission class
  *
  * @author Brett Edgar (TheWalrus) True Digital Security, Inc. www.truedigitalsecurity.com
  * @http://www.projectpier.org/
  */
  class Permission extends BasePermission {
    
  } // Permission 

?>