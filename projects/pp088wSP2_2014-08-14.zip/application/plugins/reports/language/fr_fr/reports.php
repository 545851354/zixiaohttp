<?php
/**
 * @author ALBATROS INFORMATIQUE SARL - CARQUEFOU FRANCE - Damien HENRY
 * @licence Honest Public License
 * @package ProjectPier Gantt
 * @version $Id$
 * @access public
 */
return array(
  'reports' => 'Rapports',
  
  /* GANNT */
  'gantt' => 'Gantt',
  'Download file gantt' => 'Télécharger l\'image',
  'Click here to see gantt chart' => "Cliquez ici pour voir le diagramme de Gantt",
  
  /* MINDMAPPING */ 
  'mm' => 'MindMapping',
  'Download file mindmapping' => "Télécharger le fichier",
  'Version Freemind' => 'Version Freemind 0.9.0',
  'Click here to see mindmapping' => "Cliquez ici pour voir la carte mentale",

  );
?>