<?php
/**
 * @author ALBATROS INFORMATIQUE SARL - CARQUEFOU FRANCE - Damien HENRY
 * @translator Engelbert Mercelis
 * @licence Honest Public License
 * @package ProjectPier Gantt
 * @version $Id$
 * @access public
 */
return array(
  'reports' => 'Rapporten',
  
  /* GANNT */
  'gantt' => 'Gantt',
  
  /* MINDMAP */ 
  'freemind version' => 'Freemind Version 0.9.0',
  'mindmap' => "Mind map",	// -TODO- review needed!

);
?>