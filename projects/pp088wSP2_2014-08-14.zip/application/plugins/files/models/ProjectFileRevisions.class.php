<?php

  /**
  * ProjectFileRevisions, generated on Tue, 04 Jul 2006 06:46:08 +0200 by 
  * DataObject generation tool
  *
  * @http://www.projectpier.org/
  */
  class ProjectFileRevisions extends BaseProjectFileRevisions {
  
  } // ProjectFileRevisions 

?>