<?php

  /**
  * ImTypes, generated on Wed, 22 Mar 2006 15:35:34 +0100 by 
  * DataObject generation tool
  *
  * @http://www.projectpier.org/
  */
  class ImTypes extends BaseImTypes {
  
  } // ImTypes 

?>