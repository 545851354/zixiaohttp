<?php

  return array(

    'tag' => 'Tag',
    'tags' => 'Tags',

    'tags used on projects' => 'Tags utilisés dans ce projet',
    'number of tagged objects' => '%s objet(s)',
    'total objects tagged with' => '<b>%s</b> objets portent le tag <b>%s</b> dans ce projet',
    'no objects tagged with' => 'Aucun objet ne porte le tag <b>%s</b>',
    'tags widget description' => 'Liste de tags séparés par des virgules (exemple: "interface, javascript, beta publique")',
    
  );

?>