<?php

  return array(

    'tag' => 'Merki',
    'tags' => 'Merki',

    'tags used on projects' => 'Merki notuð í þessu verkefni',
    'number of tagged objects' => '%s hlutir',
    'total objects tagged with' => 'Það eru <b>%s</b> hlutir merktir með <b>%s</b> í þessu verkefni',
    'no objects tagged with' => 'Það eru engir hlutir í þessu verkefni merktir með <b>%s</b>',
    'tags widget description' => 'Listi af merkjum aðskildum með kommum (dæmi: "fjármál, pengingar, gjafir")',
    
  );

?>