<?php
  //ProjectPier russian language module
  // Translated by Alexander Selifonov, < alex [at] selifan {dot} ru >
  return array(

    'tag' => 'Тэг',
    'tags' => 'Тэги',

    'tags used on projects' => 'Тэги в этом проекте',
    'number of tagged objects' => '%s объект(ов)',
    'total objects tagged with' => 'Всего в проекте <b>%s</b> объектов с тэгом <b>%s</b>',
    'no objects tagged with' => 'В проекте нет объектов с тэгом <b>%s</b>',
    'tags widget description' => 'Список тэгов (разделять запятой: "interface, javascript, public beta")',

  );

