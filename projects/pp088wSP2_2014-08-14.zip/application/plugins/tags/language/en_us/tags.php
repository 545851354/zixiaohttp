<?php

  return array(

    'tag' => 'Tag',
    'tags' => 'Tags',

    'tags used on projects' => 'Tags used on this project',
    'number of tagged objects' => '%s object(s)',
    'total objects tagged with' => 'There are <b>%s</b> objects tagged with <b>%s</b> in this project',
    'no objects tagged with' => 'There are no objects in this project tagged with <b>%s</b>',
    'tags widget description' => 'List of comma separated tags (example: "interface, javascript, public beta")',
    
  );

?>