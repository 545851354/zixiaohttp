<?php

  return array(

    'no objects tagged with' => 'Non ci sono oggetti taggati con <b>%s</b> in questo progetto',
    'number of tagged objects' => '%s oggetto(i)',
    'tag' => 'Tag',
    'tags' => 'Tag',
    'tags used on projects' => 'Tag utilizzati in questo progetto',
    'tags widget description' => 'Elenco di tag separati da virgola (ad esempio: "test, documenti, versione beta")',
    'total objects tagged with' => 'Ci sono <b>%s</b> oggetti taggati con <b>%s</b> in questo progetto',

  );

?>