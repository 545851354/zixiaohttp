<?php
 /**
 * @author Engelbert Mercelis
 * @licence Gnu Affero General Public License
 */
  return array(

    'tag' => 'Tag',
    'tags' => 'Tags',

    'tags used on projects' => 'Tags gebruikt in dit project',
    'number of tagged objects' => '%s object(en)',
    'total objects tagged with' => 'Er zijn <b>%s</b> objecten voorzien van tag: <b>%s</b>, in dit project',
    'no objects tagged with' => 'Er zijn geen objecten in dit project voorzien van tag: <b>%s</b>',
    'tags widget description' => 'Lijst met door komma gescheiden tags (voorbeeld: "interface, javascript, publieke beta")',
    
  );

?>