<div class="tags">
  <span><?php echo lang('tags') ?>:</span> <?php echo project_object_tags($object, $object->getProject()) ?>
</div>