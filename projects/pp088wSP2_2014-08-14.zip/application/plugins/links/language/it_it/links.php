<?php

  // Return array of langs
  return array(
    'link' => 'Link',
    'links' => 'Link',
    'my links' => 'I miei link',
    'project links' => 'Link di progetto',
    'add link' => 'Aggiungi link',

    'edit link' => 'Modifica link',
    'url' => 'Indirizzo URL',
    'no links found' => 'Non ci sono link in questo progetto',
    
    'success add link' => 'Link aggiunto',
    'success edit link' => 'Link modificato',
    'success delete link' => 'Link cancellato',

    'project link dnx' => 'Link non trovato',
    
    'log add projectlinks' => "Link '%s' aggiunto al progetto",
    'log edit projectlinks' => "Link '%s' modificato",
    'log delete projectlinks' => "Link '%s' cancellato",
  ); // array

?>
  