<?php

  return array(
  
    // Titles
    'link' => 'Tengill',
    'links' => 'Tenglar',
    'my links' => 'Tenglarnir mínir',
    'project links' => 'Tenglar verkefnis',
    'add link' => 'Bæta við tengli',
    'edit link' => 'Breyta tengli',
    'url' => 'Slóð (URL)',
    'no links found' => 'Engir tenglar í þessu verkefni',
    
    'success add link' => 'Tengli hefur verið bætt við',
    'success edit link' => 'Tengli hefur verið breytt',
    'success delete link' => 'Tengli hefur verið eytt',

    'project link dnx' => 'Tengill fannst ekki',
    
    'log add projectlinks' => "Tenglinum '%s' var bætt við verkefnið",
    'log edit projectlinks' => "Tenglinum '%s' var breytt",
    'log delete projectlinks' => "Tenglinum '%s' var verið eytt",
    
  ); // array

?>
