<?php echo lang('hi john doe', $user->getDisplayName()) ?>,

<?php echo lang('user password reset', $new_password) ?>

--
<?php echo externalUrl(ROOT_URL) ?>