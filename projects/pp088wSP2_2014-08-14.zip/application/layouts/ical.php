<?php header('Content-Type: text/Calendar'); ?>
<?php echo $content_for_layout ?>